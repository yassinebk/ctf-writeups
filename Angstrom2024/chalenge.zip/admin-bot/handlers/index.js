const { execute } = require("./wwwwwwwwaas.js");

execute("http://localhost:3000/exploit.html");
