module.exports = {
	ZapfDingbats: {
		normal: 'ZapfDingbats'
	}
};
