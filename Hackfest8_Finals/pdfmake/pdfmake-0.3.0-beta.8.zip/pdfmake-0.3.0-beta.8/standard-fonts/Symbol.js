module.exports = {
	Symbol: {
		normal: 'Symbol'
	}
};
