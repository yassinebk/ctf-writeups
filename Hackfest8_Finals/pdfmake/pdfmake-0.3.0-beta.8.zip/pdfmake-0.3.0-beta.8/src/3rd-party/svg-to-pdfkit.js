import SVGtoPDF from './svg-to-pdfkit/source.js';

export default SVGtoPDF;
