## Dev Playground

Start from pdfmake ROOT directory with nodemon if you want server to restart with every change you make in pdfmake/src:

```
cd dev-playground
npm install # or: yarn
npm install -g nodemon
cd ..
nodemon ./dev-playground/server.js
```
