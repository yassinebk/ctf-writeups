<?php 
echo file_get_contents("/etc/flag");
?>
