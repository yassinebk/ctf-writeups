<?php
define('in', true);
error_reporting(0);

if ($_GET['page']==='upload.blabla'){ //guess my file extention
	include('upload.blabla');
}
else if ($_GET['page']==='view.blablabla'){ //guess my file extention
	include('view.blablabla');}
else{
	die('welcome');
}
