# Lost in Amazon
- `/console` => Flask appliaction running on debug mode.
